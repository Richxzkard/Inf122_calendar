package inf122;

import java.util.ArrayList;

public class User {
    private final String user_id;

    public User (String user_id){
        this.user_id = user_id;
    }

    public String get_userid(){
        return this.user_id;
    }


}
